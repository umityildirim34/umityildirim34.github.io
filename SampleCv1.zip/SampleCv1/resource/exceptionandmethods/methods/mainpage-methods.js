

var intFinalNote;





class MainpageMethods {

  
    
}